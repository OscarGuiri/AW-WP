 </div>
 <footer id = "footer">
 	<img id="logo1" src="http://localhost/wordpress/wp-content/uploads/2019/02/wkf-logo-5B54510A61-seeklogo.com_.png"/>
 	<img id="logo2" src="http://localhost/wordpress/wp-content/uploads/2019/02/kisspng-logo-european-karate-federation-brand-world-karate-5b9a7f203b6b95.4037582415368517442434.png"/>
 	<img id="logo3" src="http://localhost/wordpress/wp-content/uploads/2019/02/logo-rfek-transparente-300x300.png"/>
 	
 	<p>&copy; <?php echo date('Y'); ?></p>
 </footer>
</body>
</html>