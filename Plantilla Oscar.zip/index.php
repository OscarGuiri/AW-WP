<?php get_header(); ?>
 <?php get_sidebar() ?>    
 
 
<div class="main">
         
 
 
<div class="container">

            <?php if(have_posts()) : ?>
                <?php while(have_posts()): the_post(); ?>
                     
 
 
<h3><?php the_title(); ?></h3>
 <hr>
 
 
                     
 
 
<div class="meta">
                    Created By <?php the_author(); ?> on <?php the_time('F j, Y g:i a'); ?>
                    </div>
 
 
 
                    <?php the_content(); ?>
                <?php endwhile; ?>
            <?php else : ?>
                <?php echo wpautop('No se han encontrado posts'); ?>
            <?php endif; ?>
        </div>
 
 
 
    </div>
 
 
 
 
<?php get_footer(); ?>