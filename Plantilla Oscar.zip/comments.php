<div id="comments">
	<?php wp_list:comments();?>
	
</div>
<div id="comment-form">
	<?php comment_form() ?>

</div>