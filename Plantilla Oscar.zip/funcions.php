<?php

register_sidebar(array(
	'name' => 'Right Sidebar',

));