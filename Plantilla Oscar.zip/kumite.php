<?php the_title()?>
<?php get_header(); ?>
<?php get_sidevar()?>

 
 <div id="left">
	
<?php while(have_posts()): the_post()?>

		<h2><?php the_title()?></h2>
		<?php the_content();?>
<?php endwhile;?>

<?php comments_template('',true);?>
</div>
<?php the_content();?>
<a class="button" href="<?php the_permalink(); ?>">
	read more
</a>


<?php get_footer() ?>
