<div id="sidebar">

	
	<?php dynamic_sidebar('first-right-sidebar');?>
	<?php dynamic_sidebar('second-right-sidebar');?>

</div>