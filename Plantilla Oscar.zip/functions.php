<?php
function simple_theme_setup(){
    // Featured Image Support
    add_theme_support('post-thumbnails');
}
 
add_action('after_setup_theme', 'simple_theme_setup');
 
 
// Excerpt Length
function set_excerpt_length(){
    return 60;
}
 
add_filter('excerpt_length', 'set_excerpt_length');


register_sidebar(array(
	'name' => __('1st Right Sidebar'),
	'id' => 'first-right-sidebar',
	'description' => 'The top bar',
	'before_widget' => '<div>',
	'after_widget' => '</div>'

	

));
register_sidebar(array(
	'name' => __('2nd Right Sidebar'),
	'id' => 'second-right-sidebar',
	'description' => 'The top bar',
	'before_widget' => '<div>',
	'after_widget' => '</div>'

	

));

register_default_headers( array(
	'wheel' => array(
		'url'           => '%s/images/headers/wheel.jpg',
		'thumbnail_url' => '%s/images/headers/wheel-thumbnail.jpg',
		'description'   => __( 'Wheel', 'twentyeleven' )
	),
	'shore' => array(
		'url'           => '%s/images/headers/shore.jpg',
		'thumbnail_url' => '%s/images/headers/shore-thumbnail.jpg',
		'description'   => __( 'Shore', 'twentyeleven' )
	),
	'trolley' => array(
		'url'           => '%s/images/headers/trolley.jpg',
		'thumbnail_url' => '%s/images/headers/trolley-thumbnail.jpg',
		'description'   => __( 'Trolley', 'twentyeleven' )
	)
) );

$defaults = array(
	'default-image'          => '',
	'width'                  => 0,
	'height'                 => 0,
	'flex-height'            => false,
	'flex-width'             => false,
	'uploads'                => true,
	'random-default'         => false,
	'header-text'            => true,
	'default-text-color'     => '',
	'wp-head-callback'       => '',
	'admin-head-callback'    => '',
	'admin-preview-callback' => '',
);
add_theme_support( 'custom-header', $defaults );