<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="utf-8">
	<title><?php bloginfo('name'); ?></title>
	<!--[if lt IE 9]>
  <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>">
	<?php wp_head() ?>
</style>
</head>
<body>
	
	<div id= "container">
 <header>

 		<h1><a href="<?php echo home_url('/') ?>"><?php bloginfo('name'); ?></a></h1>
 		<span><?php bloginfo ('description')?></span>
 <div id=sidebar >

	<?php get_search_form(); ?>
	
</div>

<nav>
	<?php wp_nav_menu() ?>

</nav>	

 </header>

 <div id= "container2">


 <?php $args = array( 'theme_location' => 'primary'
    );
?>

